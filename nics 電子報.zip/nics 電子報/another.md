<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;700;800;900&family=JetBrains+Mono:wght@500;700&display=swap');

  /* 全域樣式：深色底色與淺色文字 */
  body {
    margin: 0;
    padding: 0;
    background: #0f1115;
    color: #e2e8f0;
    font-family: 'Inter', 'Microsoft JhengHei', sans-serif;
    line-height: 1.6;
  }

  /* 內文容器樣式 */
  .content-wrapper {
    max-width: 900px;
    margin: 0 auto;
    padding: 60px 40px;
    background: #0f1115;
  }

  /* 確保所有 P 標籤在黑底上呈現淺色 */
  p,
  .content-wrapper p {
    color: #e2e8f0 !important;
    margin-bottom: 1.2em;
  }

  /* 強制所有內文清單與表格文字顯示為淺色 */
  .content-wrapper li,
  .content-wrapper td {
    color: #cbd5e1 !important;
  }

  /* 標題樣式 */
  .content-wrapper h1,
  .content-wrapper h2,
  .content-wrapper h3 {
    color: #ffffff !important;
    border-bottom: 1px solid rgba(239, 68, 68, 0.4);
    padding-bottom: 12px;
    margin-top: 2em;
    font-weight: 800;
  }

  .content-wrapper h1::before {
    content: "> ";
    color: #ef4444;
  }

  /* 表格優化 */
  .content-wrapper table {
    width: 100%;
    border-collapse: collapse;
    margin: 30px 0;
    background: rgba(30, 41, 59, 0.4);
    border: 1px solid rgba(255, 255, 255, 0.1);
  }

  .content-wrapper th {
    background: #1e293b;
    color: #f87171 !important;
    text-align: left;
    padding: 14px;
    font-size: 0.9em;
    text-transform: uppercase;
    border-bottom: 2px solid #ef4444;
  }

  .content-wrapper td {
    padding: 14px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.05);
  }

  /* 程式碼區塊 /
.content-wrapper code {
font-family: 'JetBrains Mono', monospace;
background: #1a1c23;
color: #34d399; / 矩陣綠 */
  padding: 3px 8px;
  border-radius: 4px;
  }

  .content-wrapper pre {
    background: #161b22 !important;
    border-left: 4px solid #ef4444;
    padding: 20px;
    border-radius: 0 8px 8px 0;
    margin: 20px 0;
  }

  /* 封面樣式保持 */
  #cover-page {
    position: relative;
    box-sizing: border-box;
    width: 100%;
    min-height: 290mm;
    padding: 16mm;
    background: linear-gradient(180deg, #0a0505 0%, #140808 100%);
    color: #f8fafc;
    border-bottom: 4px solid #dc2626;
  }

  #cover-page::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-image:
      linear-gradient(rgba(255, 45, 85, 0.06) 1px, transparent 1px),
      linear-gradient(90deg, rgba(255, 45, 85, 0.06) 1px, transparent 1px);
    background-size: 28px 28px;
    pointer-events: none;
  }

  .cover-frame {
    position: relative;
    z-index: 1;
    width: 100%;
    max-width: 980px;
    margin: 0 auto;
    border: 2px solid rgba(127, 29, 29, 0.45);
    background: rgba(18, 8, 8, 0.96);
    padding: 40px;
  }

  .corner {
    position: absolute;
    width: 24px;
    height: 24px;
  }

  .corner.tl {
    top: 0;
    left: 0;
    border-top: 2px solid #dc2626;
    border-left: 2px solid #dc2626;
  }

  .corner.tr {
    top: 0;
    right: 0;
    border-top: 2px solid #dc2626;
    border-right: 2px solid #dc2626;
  }

  .corner.bl {
    bottom: 0;
    left: 0;
    border-bottom: 2px solid #dc2626;
    border-left: 2px solid #dc2626;
  }

  .corner.br {
    bottom: 0;
    right: 0;
    border-bottom: 2px solid #dc2626;
    border-right: 2px solid #dc2626;
  }

  .org-icon {
    width: 32px;
    height: 32px;
    background: #dc2626;
    color: #fff;
    text-align: center;
    line-height: 32px;
    display: inline-block;
    font-weight: 900;
  }

  .org-title {
    font-size: 28px;
    font-weight: 900;
    margin: 0;
    color: #fff;
    display: inline-block;
    vertical-align: middle;
    padding-left: 10px;
  }

  .meta-id {
    font-size: 20px;
    font-weight: 800;
    color: #f87171;
    margin: 0;
  }

  .live-tag {
    display: inline-block;
    padding: 4px 12px;
    border: 1px solid #f87171;
    color: #f87171;
    font-size: 10px;
    font-weight: 800;
    text-transform: uppercase;
    margin-top: 10px;
  }

  .cover-main h1 {
    font-size: 64px;
    font-weight: 900;
    font-style: italic;
    margin: 40px 0 10px 0;
    line-height: 1;
    border: none;
    color: #fff !important;
  }

  .cover-main h1 .highlight {
    color: #ef4444 !important;
  }

  .info-card {
    display: inline-block;
    width: 48%;
    border: 1px solid rgba(127, 29, 29, 0.5);
    background: rgba(127, 29, 29, 0.1);
    padding: 20px;
    box-sizing: border-box;
  }

  .info-card.critical {
    border: 2px solid #dc2626;
  }

  .info-label {
    color: #ef4444;
    font-size: 10px;
    font-weight: 800;
    text-transform: uppercase;
    margin-bottom: 5px;
  }

  .info-value {
    font-size: 24px;
    font-weight: 900;
    color: #fff;
    margin: 0;
  }

  .tlp-value {
    padding: 8px 20px;
    background: #16a34a;
    color: #fff;
    font-weight: 900;
    display: inline-block;
  }

  .page-break {
    page-break-after: always;
  }
</style>
<!-- 封面部分 -->
<div id="cover-page">
  <div class="cover-frame">
    <div class="corner tl"></div>
    <div class="corner tr"></div>
    <div class="corner bl"></div>
    <div class="corner br"></div>
    <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 1px solid rgba(127,29,29,0.3); padding-bottom: 20px;">
      <div>
        <div class="org-icon">S</div>
        <p class="org-title">TWCERT/CC</p>
        <p style="color: #f87171; font-size: 10px; margin: 5px 0 0 0; text-transform: uppercase; letter-spacing: 2px;">Threat Intelligence Division</p>
      </div>
      <div style="text-align: right;">
        <p style="color: #b91c1c; font-size: 10px; font-weight: 800; margin: 0;">REPORT IDENTIFIER</p>
        <p class="meta-id">NICS-260301-02</p>
        <div class="live-tag">Flash Report</div>
      </div>
    </div>
    <div class="cover-main">
      <p style="color: #ef4444; font-size: 11px; font-weight: 800; letter-spacing: 3px; margin: 40px 0 0 0;">RESTRICTED ACCESS INTEL</p>
      <h1 style="color: #fff !important;">COLDLOCK <br>
        <span class="highlight">RANSOMWARE</span>
      </h1>
      <div style="display: flex; gap: 5px; margin-top: 20px;">
        <div style="width: 60px; height: 6px; background: #dc2626;"></div>
        <div style="width: 20px; height: 6px; background: #7f1d1d;"></div>
        <div style="width: 10px; height: 6px; background: #7f1d1d;"></div>
      </div>
    </div>
    <div style="display: flex; justify-content: space-between; margin-top: 40px;">
      <div class="info-card">
        <p class="info-label">Target Sector</p>
        <p class="info-value">Energy / Tech</p>
        <p style="color: rgba(248,113,113,0.7); font-size: 10px; margin-top: 5px;">Region: Taiwan</p>
      </div>
      <div class="info-card critical">
        <p class="info-label">Threat Level</p>
        <p class="info-value">CRITICAL / HIGH</p>
        <p style="color: rgba(248,113,113,0.7); font-size: 10px; margin-top: 5px;">Confidence: Medium</p>
      </div>
    </div>
    <div style="margin-top: 40px; padding-left: 20px; border-left: 4px solid #dc2626;">
      <p style="font-style: italic; color: #fee2e2; font-size: 15px;"> 本報告揭露 COLDLOCK 勒索軟體鎖定台灣科技與能源領域之攻擊活動，惡意程式使用 RSA 2048 與 AES 加密機制，具明確勒索與營運中斷風險。 </p>
    </div>
    <div style="margin-top: 40px; display: flex; justify-content: space-between; align-items: flex-end; border-top: 1px solid rgba(127,29,29,0.3); padding-top: 20px;">
      <div style="display: flex; gap: 30px;">
        <div>
          <p class="info-label">Published</p>
          <p style="color:#fff; font-weight:800; margin:0;">2026.03.03</p>
        </div>
        <div>
          <p class="info-label">Initial Access</p>
          <p style="color:#fff; font-weight:800; margin:0;">Phishing</p>
        </div>
      </div>
      <div style="text-align: right;">
        <p class="info-label">Traffic Light Protocol</p>
        <div class="tlp-value">TLP:GREEN</div>
      </div>
    </div>
  </div>
</div>
<div class="page-break"></div>
<!-- 內文部分 -->

# COLDLOCK 勒索軟體針對台灣科技和能源業進行攻擊
| 欄位 | 內容 |
|------|------|
| 報告編號 | NICS-260301-02  |
| 報告類型 | Flash Report |
| 發布日期 | 2026.03.03 |
|信心等級|中|
|威脅等級|高|
| 受影響產業 | 能源、科技業 |
| 受害地區 | 台灣 |
|駭客組織|-|
| 惡意程式名稱 | COLDLOCK Ransomware |
|勒索軟體使用的演算法|RSA 2048、AES|
|加密後檔案副檔名|`.locked`|
|Ransom note|-|
|初始入侵方式|釣魚郵件|
| TLP | Green |

# 摘要

本報告揭露一起透過`COLDLOCK .NET` 勒索軟體以台灣石油天然氣產業為目標，使用了 RSA 2048 和 AES 加密文件，並在加密後的檔案名稱添加 `.locked` 來索取贖金

因為攻擊者使用的攻擊手法和策略在勒索軟體業者中很常見，無法判斷該歸因給任何特定的攻擊組織

值得注意的是，這次觀察到的`COLDLOCK`勒索軟體使用 GMT+8 時區（台灣時區）計算系統時間，並且僅在每天下午 12:10 或之後運行；其他時間則處於休眠狀態。這顯示此次攻擊活動的目標區域為亞太地區

# 攻擊流程

| 階段 | 行為 | 說明 |
|---|---|---|
| 1 | 檢查檔案修改時間 | 用 2018-01-01 作為分界 |
| 2 | 比對副檔名 | 確定是否為目標檔案 |
| 3 | 加密檔案 | 將資料加密鎖住 |
| 4 | 修改檔名 | 加上 .locked |
| 5 | 發送通知 | 提示受害者查看勒索訊息 |

# 技術分析

`COLDLOCK` 是一個 `.NET` 撰寫的勒索軟體，唯一目的是枚舉並加密受害者電腦上的檔案。

`COLDLOCK`勒索軟體會由 powershell 腳本(SHA256: 08677a3dac3609d13dc4a2a6868ee2f6c1334f4579356d162b706a03839bb9ff)啟動。此 PowerShell 腳本包含 COLDLOCK 勒索軟體的 Base64 編碼版本（MD5：c5108344e8a6da617af1c4a7fd8924a64130b4c86fa0f6d6225bb75534a80a35）


`COLDLOCK`在電腦中運作時，會先做一件事：**先找出電腦裡有哪些資料和資料夾可以加密**

掃描的資料夾如下
| 目錄路徑 | 白話說明 | 為什麼重要 |
|---|---|---|
| %SYSTEMDRIVE%\Program Files | Windows 安裝應用程式的位置 | 很多伺服器程式或資料庫會在這裡 |
| %SYSTEMDRIVE%\Program Files (x86) | 32位元應用程式安裝位置 | 可能包含舊版資料庫或應用 |
| %SYSTEMDRIVE%\ProgramData | 系統與程式共用資料 | 很多服務會把資料存在這裡 |
| %SYSTEMDRIVE%\Users | 使用者個人資料 | 可能包含重要文件或資料 |

掃描的目的和行為整理如下表
| 行為 | 說明 |
|---|---|
| 搜尋關鍵字 | 尋找路徑包含 sql、mariadb、oracle |
| 找到後 | 將檔案加入「準備加密清單」 |
| 最終目的 | 進行勒索加密 |

之後會再次進行深度的掃描，確保找到更多檔案進行加密勒索，深度搜尋的資料夾如下表整理

| 目錄路徑 | 白話說明 | 可能包含的資料 |
|---|---|---|
| %SYSTEMDRIVE%\ProgramData\Microsoft\Windows\Start Menu | Windows 開始選單資料 | 程式捷徑與設定 |
| %SYSTEMDRIVE%\Program Files\Microsoft\Exchange Server | Microsoft Exchange 郵件伺服器 | 企業郵件資料 |
| %SYSTEMDRIVE%\Program Files (x86)\Microsoft\Exchange Server | Exchange 32位元版本 | 郵件服務資料 |
| %SYSTEMDRIVE%\Users\all users | 所有使用者共用資料 | 共用設定或文件 |
| %SYSTEMDRIVE%\Users\default | Windows 預設使用者資料 | 新使用者的預設設定 |
| <Path of COLDLOCK> | 勒索軟體自身所在位置 | 可能掃描附近檔案 |
| %SYSTEMDRIVE%\Users | 使用者資料夾 | 文件、桌面、下載資料 |
| %TEMP% | 暫存資料夾 | 程式暫存檔案 |


整理完檔案清單之後， `COLDLOCK`勒索軟體會根據**檔案修改時間**來判斷是否加密
    
如果檔案的最後修改時間晚於 2018-01-01，且符合底下相關的副檔案，才會進行加密勒索，整理如下表：
| 副檔名 | 檔案類型 | 白話說明 |
|---|---|---|
| .dll | 動態函式庫 | Windows 程式使用的核心檔案 |
| .ocx | ActiveX 元件 | 舊式 Windows 控制元件 |
| .msi | 安裝程式 | Windows 軟體安裝包 |
| .iso | 光碟映像檔 | 系統或軟體安裝映像 |
| .mkv | 影片 | 常見影片格式 |
| .mov | 影片 | Apple 影片格式 |
| .avi | 影片 | 常見影片格式 |
| .wmv | 影片 | Windows Media 影片 |
| .m2ts | 高畫質影片 | 藍光影片格式 |
| .mp3 | 音樂 | 常見音訊格式 |
| .tmp | 暫存檔 | 程式暫時使用檔案 |
| .gif | 圖片 | 動畫圖片格式 |
    

如果檔案最後修改時間早於 2018-01-01 ，則會判斷另一批副檔案名稱進行勒索，整理如下表：
| 副檔名 | 檔案類型 | 白話說明 |
|---|---|---|
| .txt | 文字檔 | 一般文字文件 |
| .doc | Word 文件 | Microsoft Word |
| .docx | Word 文件 | 新版 Word |
| .xls | Excel | 試算表 |
| .xlsx | Excel | 新版 Excel |
| .ppt | PowerPoint | 簡報 |
| .pptx | PowerPoint | 新版簡報 |
| .odt | OpenDocument | 開源文件格式 |
| .hwp | 韓文文件 | 韓國常用文件格式 |
| .pst | Outlook 郵件 | 郵件資料庫 |
| .sh | Shell Script | Linux 腳本 |
| .one | OneNote | Microsoft 筆記 |
| .csv | CSV | 資料表 |
| .bak | 備份檔 | 備份資料 |
| .lnk | Windows 捷徑 | 程式捷徑 |
| .jpg | 圖片 | 常見圖片 |
| .sql | 資料庫 | SQL 資料 |
| .php | 程式碼 | Web 伺服器程式 |
| .cpp | 程式碼 | C++ 程式 |
| .jsp | 程式碼 | Java Web |
| .java | 程式碼 | Java 程式 |
| .zip | 壓縮檔 | 壓縮資料 |
| .rar | 壓縮檔 | 壓縮資料 |
| .7z | 壓縮檔 | 高壓縮格式 |
| .gz | 壓縮檔 | Linux 壓縮 |
| .aspx | Web 程式 | ASP.NET |
| .xml | 設定檔 | 系統或應用設定 |
    
    
加密後的資料會在最後面添加 `.locked` ，範例如下表整理：
| 原始檔案 | 加密後檔案 |
|---|---|
| report.docx | report.docx.locked |
| database.sql | database.sql.locked |
| photo.jpg | photo.jpg.locked |

    
最後攻擊者會顯示勒索訊息(Ransom Note) 告知使用者被勒索以及要求付費，勒索訊息如下圖



![image](./ransom_test.png)
圖1: Ransom Note

    



# 防禦與緩解建議


# 偵測規則


## Yara Rule

```
rule FE_HUNT_COLDLOCK_strings {

  meta:

disclaimer = "This rule is meant for hunting and is not tested to run in a production environment"

description = "Detects strings within confuserex versions of COLDLOCK"

author = "Mandiant"

date = "2020-05-06"

  strings:

$s0 = "PSObject"

$s2 = "GetProcessesByName"

$s3 = "IPAddress"

$s4 = "DirectoryInfo"

$s5 = "Directory"

$s6 = "GetParent"

$s7 = "GetDirectories"

$s8 = "FileSystemInfo"

$s9 = "DriveInfo"

$s10 = "DriveType"

$s11 = "GetDrives"

$s12 = "get_DriveType"

$s13 = "Exists"

$s14 = "FileInfo"

$s15 = "FileStream"

$s16 = "ReadAllBytes"

$s17 = "GetFiles"

$s18 = "ToBase64String"

$s19 = "Base64FormattingOptions"

$s20 = "RSACryptoServiceProvider"

$s21 = "AsymmetricAlgorithm"

$s22 = "FromXmlString"

$s23 = "Encrypt"

$s24 = "RijndaelManaged"

$s25 = "Rfc2898DeriveBytes"

$s26 = "CryptoStream"

$s27 = "SymmetricAlgorithm"

$s28 = "set_Mode"

$s29 = "CipherMode"

$s30 = "set_Padding"

$s31 = "set_KeySize"

$s32 = "set_BlockSize"

$s33 = "get_KeySize"

$s34 = "DeriveBytes"

$s35 = "set_Key"

$s36 = "get_BlockSize"

$s37 = "set_IV"

$s38 = "CreateEncryptor"

$s39 = "ICryptoTransform"

$s40 = "CryptoStreamMode"

$s41 = "RandomNumberGenerator"

$s42 = "RegistryValueKind"

$s43 = "GetEnvironmentVariable"

$s44 = "GetFolderPath"

$s45 = "SpecialFolder"

$s46 = "GetTempPath"

$s47 = "get_MachineName"

$confuse = "ConfusedBy"

  condition:

uint16(0) == 0x5A4D and uint32(uint32(0x3C)) == 0x00004550 and $confuse and (42 of ($s*))

}
```


# 附錄

## MITRE ATT&CK 
    
| ID | 技術名稱 | 簡要說明 |
|----|----------|----------|
| T1485 | 資料破壞 (Data Destruction) | 攻擊者刪除或破壞系統資料，使系統或服務無法恢復。 |
| T1486 | 勒索加密 (Data Encrypted for Impact) | 將資料加密使組織無法存取，通常用於勒索攻擊。 |
| T1488 | 磁碟內容清除 (Disk Content Wipe) | 清除或覆寫磁碟資料，導致資料無法復原。 |
| T1031 | 修改既有服務 (Modify Existing Service) | 修改系統服務設定或權限，以維持存取或提升權限。 |
| T1045 | 軟體封裝 (Software Packing) | 使用封裝或混淆技術隱藏惡意程式，避免被防毒偵測。 |
| T1064 | 腳本執行 (Scripting) | 利用腳本語言（如 VBScript、PowerShell）執行惡意指令。 |
| T1086 | PowerShell | 利用 PowerShell 在系統中執行指令或遠端操作。 |
| T1089 | 停用安全工具 (Disabling Security Tools) | 停用或干擾防毒、防護服務等安全機制。 |
    
    
## IOC

| Filename              | SHA-256 |
|------------------------|------------------------|
|[NSIS].nsi|8ea8b83645fba6e23d48075a0d3fc73ad2ba515b4536710cda4f1f232718f53e|
|BluetoothService |77bfea78def679aa1117f569a35e8fd1542df21f7e00e27f192c907e61d63a2e|
|log.dll|3bdc4c0637591533f1d4198a72a33426c01f69bd2e15ceee547866f65e26b7ad|



| Indicator              |
|------------------------|
| 95.179.213.0           |
| api[.]skycloudcenter[.]com |
| api[.]wiresguard[.]com |
| 61.4.102.97            |
| 59.110.7.32            |
| 124.222.137.114        |

## Reference

https://www.virustotal.com/gui/collection/report--20-00008620 
