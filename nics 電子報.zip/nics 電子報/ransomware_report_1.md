<style>
/* 載入乾淨的無襯線與等寬字體 */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&family=JetBrains+Mono:wght@500&display=swap');

body {
    margin: 0;
    padding: 0;
    background-color: #ffffff;
}

#cover-page {
    height: 98vh; /* 略縮一點，確保列印不溢位 */
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    background-color: #ffffff;
    color: #1a1a1a;
    font-family: 'Inter', "Microsoft JhengHei", sans-serif;
    position: relative;
    border: 20px solid #f8f9fa; /* 淺灰色外框增加層次 */
}

/* 頂部裝飾條：增加權威感 */
.top-bar {
    position: absolute;
    top: 0;
    width: 100%;
    height: 8px;
    background: linear-gradient(90deg, #003366 0%, #d90429 100%);
}

.title-container {
    text-align: center;
    z-index: 1;
}

/* 主標題：使用極粗體與深藍色 */
.title-box h1 {
    font-size: 72px;
    font-weight: 900;
    margin: 0;
    color: #001d3d;
    letter-spacing: -1px; /* 緊湊排版更顯張力 */
    line-height: 1;
}

/* 副標題：紅黑配色，強調威脅感 */
.title-box h2 {
    font-family: 'JetBrains Mono', monospace;
    font-size: 24px;
    margin: 15px 0 40px 0;
    color: #d90429; /* 警示紅 */
    text-transform: uppercase;
    letter-spacing: 4px;
    font-weight: 700;
}

/* 分隔線設計 */
.divider {
    width: 60px;
    height: 4px;
    background-color: #001d3d;
    margin: 0 auto;
}

/* 底部資訊欄：模擬報告編號與日期 */
.report-meta {
    margin-top: 60px;
    font-size: 14px;
    color: #666;
    line-height: 2;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.report-meta span {
    font-weight: bold;
    color: #1a1a1a;
    border-left: 3px solid #00d4ff;
    padding-left: 10px;
    margin-left: 10px;
}

/* 頁腳：TLP 燈號標示 (資安情資常用) */
.tlp-label {
    position: absolute;
    bottom: 50px;
    padding: 4px 12px;
    border: 2px solid #00b050; /* TLP:GREEN 範例 */
    color: #00b050;
    font-weight: bold;
    font-size: 12px;
    border-radius: 4px;
}

/* 強制分頁符號 */
.page-break {
    page-break-after: always;
}
</style>

<div id="cover-page">
    <div class="title-box">
        <h1>TWCERT/CC</h1>
        <h2>Threat Intelligence Report ⚡</h2>
    </div>
</div>

<div class="page-break"></div>


# COLDLOCK 勒索軟體針對台灣科技和能源業進行攻擊
| 欄位 | 內容 |
|------|------|
| 報告編號 | NICS-260301-02  |
| 報告類型 | Flash Report |
| 發布日期 | 2026.03.03 |
|信心等級|中|
|威脅等級|高|
| 受影響產業 | 能源、科技業 |
| 受害地區 | 台灣 |
|駭客組織|-|
| 惡意程式名稱 | COLDLOCK Ransomware |
|勒索軟體使用的演算法|RSA 2048、AES|
|加密後檔案副檔名|`.locked`|
|Ransom note|-|
|初始入侵方式|釣魚郵件|
| TLP | Green |

https://www.virustotal.com/gui/collection/report--20-00008620 
# 摘要

本報告揭露一起透過`COLDLOCK .NET` 勒索軟體以台灣石油天然氣產業為目標，使用了 RSA 2048 和 AES 加密文件，並在加密後的檔案名稱添加 `.locked` 來索取贖金

因為攻擊者使用的攻擊手法和策略在勒索軟體業者中很常見，無法判斷該歸因給任何特定的攻擊組織

# 技術分析

2020年 5 月初，名為`COLDLOCK`的新型 .NET 勒索軟體針對<a href="#fn1" id="ref1"><sup>[1]</sup></a>


這是一個測試<a href="#fn2" id="ref2"><sup>[2]</sup></a>



檔案整理於下表

| 檔案名稱               | 檔案描述                                           | SHA256                                                             |
|------------------------|--------------------------------------------------|--------------------------------------------------------------------|
| [NSIS].nsi             | NSIS 安裝腳本                                     | 8ea8b83645fba6e23d48075a0d3fc73ad2ba515b4536710cda4f1f232718f53e     |
| BluetoothService.exe   | Bitdefender 程式（正常程式，用於 DLL side-loading） | 2da00de67720f5f13b17e9d985fe70f10f153da60c9ab1086fe58f069a156924     |
| BluetoothService       | 加密的負載                                         | 77bfea78def679aa1117f569a35e8fd1542df21f7e00e27f192c907e61d63a2e     |
| log.dll                | 惡意的 DLL 載入器                                  | 3bdc4c0637591533f1d4198a72a33426c01f69bd2e15ceee547866f65e26b7ad     |







![image](https://hackmd.io/_uploads/H1On5n0K-e.png)
圖1: Ransom Note







# 防禦與緩解建議


# 偵測規則


## Yara Rule

```
rule FE_HUNT_COLDLOCK_strings {

  meta:

disclaimer = "This rule is meant for hunting and is not tested to run in a production environment"

description = "Detects strings within confuserex versions of COLDLOCK"

author = "Mandiant"

date = "2020-05-06"

  strings:

$s0 = "PSObject"

$s2 = "GetProcessesByName"

$s3 = "IPAddress"

$s4 = "DirectoryInfo"

$s5 = "Directory"

$s6 = "GetParent"

$s7 = "GetDirectories"

$s8 = "FileSystemInfo"

$s9 = "DriveInfo"

$s10 = "DriveType"

$s11 = "GetDrives"

$s12 = "get_DriveType"

$s13 = "Exists"

$s14 = "FileInfo"

$s15 = "FileStream"

$s16 = "ReadAllBytes"

$s17 = "GetFiles"

$s18 = "ToBase64String"

$s19 = "Base64FormattingOptions"

$s20 = "RSACryptoServiceProvider"

$s21 = "AsymmetricAlgorithm"

$s22 = "FromXmlString"

$s23 = "Encrypt"

$s24 = "RijndaelManaged"

$s25 = "Rfc2898DeriveBytes"

$s26 = "CryptoStream"

$s27 = "SymmetricAlgorithm"

$s28 = "set_Mode"

$s29 = "CipherMode"

$s30 = "set_Padding"

$s31 = "set_KeySize"

$s32 = "set_BlockSize"

$s33 = "get_KeySize"

$s34 = "DeriveBytes"

$s35 = "set_Key"

$s36 = "get_BlockSize"

$s37 = "set_IV"

$s38 = "CreateEncryptor"

$s39 = "ICryptoTransform"

$s40 = "CryptoStreamMode"

$s41 = "RandomNumberGenerator"

$s42 = "RegistryValueKind"

$s43 = "GetEnvironmentVariable"

$s44 = "GetFolderPath"

$s45 = "SpecialFolder"

$s46 = "GetTempPath"

$s47 = "get_MachineName"

$confuse = "ConfusedBy"

  condition:

uint16(0) == 0x5A4D and uint32(uint32(0x3C)) == 0x00004550 and $confuse and (42 of ($s*))

}
```


# 附錄

## MITRE ATT&CK 
| ATT&CK ID   | Name                                                                 |
|------------|----------------------------------------------------------------------|
| T1204.002  | User Execution: Malicious File                                      |
| T1036      | Masquerading                                                         |
| T1027      | Obfuscated Files or Information                                      |
| T1027.007  | Obfuscated Files or Information: Dynamic API Resolution              |
| T1140      | Deobfuscate/Decode Files or Information                              |
| T1574.002  | DLL Side-Loading                                                     |
| T1106      | Native API                                                           |
| T1055      | Process Injection                                                    |
| T1620      | Reflective Code Loading                                              |
| T1059.003  | Command and Scripting Interpreter: Windows Command Shell            |
| T1083      | File and Directory Discovery                                         |
| T1005      | Data from Local System                                               |
| T1105      | Ingress Tool Transfer                                                |
| T1041      | Exfiltration Over C2 Channel                                         |
| T1071.001  | Application Layer Protocol: Web Protocols (HTTP/HTTPS)              |
| T1573      | Encrypted Channel                                                    |
| T1547.001  | Boot or Logon Autostart Execution: Registry Run Keys                |
| T1543.003  | Create or Modify System Process: Windows Service                    |
| T1480.002  | Execution Guardrails: Mutual Exclusion                               |
| T1070.004  | Indicator Removal on Host: File Deletion                             |
## IOC

| Filename              | SHA-256 |
|------------------------|------------------------|
|[NSIS].nsi|8ea8b83645fba6e23d48075a0d3fc73ad2ba515b4536710cda4f1f232718f53e|
|BluetoothService |77bfea78def679aa1117f569a35e8fd1542df21f7e00e27f192c907e61d63a2e|
|log.dll|3bdc4c0637591533f1d4198a72a33426c01f69bd2e15ceee547866f65e26b7ad|



| Indicator              |
|------------------------|
| 95.179.213.0           |
| api[.]skycloudcenter[.]com |
| api[.]wiresguard[.]com |
| 61.4.102.97            |
| 59.110.7.32            |
| 124.222.137.114        |

## Reference

- https://www.rapid7.com/blog/post/tr-chrysalis-backdoor-dive-into-lotus-blossoms-toolkit/


<hr>

<div id="fn1">
    <strong>[1]</strong> <a href="https://portswigger.net/">https://portswigger.net/</a> 
    <a href="#ref1">↩</a>
</div>


<div id="fn2">
    <strong>[2]</strong> <a href="https://ntust.edu.tw">https://ntust.edu.tw</a> 
    <a href="#ref2">↩</a>
</div>