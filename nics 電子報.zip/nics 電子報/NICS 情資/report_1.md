# 中國 APT 組織 Lotus Blossom劫持了 Notepad++ 的更新伺服器，以此傳播惡意程式
| 欄位 | 內容 |
|------|------|
| 報告編號 | NICS-260301-01  |
| 報告類型 | Flash Report |
| 發布日期 | 2026.03.03 |
|信心等級|中|
|威脅等級|高|
| 受影響產業 | 金融、科技業、電信服務 |
| 受害地區 | 台灣、香港 |
|駭客組織|Lotus Blossom|
| 惡意程式名稱 | Chrysalis（Rapid7 命名） |
| TLP | Green |


# 摘要

本報告揭露一起針對 Notepad++ 更新伺服器的供應鏈攻擊。中國威脅行為者 Lotus Blossom 入侵更新伺服器並竄改安裝包，利用 DLL Side-loading 技術植入名為 Chrysalis 的新型後門。受害者主要集中於台灣與香港的科技業與金融機構。


# 技術分析

執行時，安裝腳本 `[NSIS].nsi ` 會在 `%AppData%`資料夾中建立 `Bluetooth` 資料夾，並變更該資料夾屬性為隱藏，之後執行 `BluetoothService.exe`

`BluetoothService.exe` 會透過 DLL Side-Loading 技術載入惡意的 `log.dll` 之後解密負載`BluetoothService`，最終得到一個後門程式，由 Rapid7 資安公司命名為 Chrysalis

惡意程式會跟駭客的伺服器: `api.skycloudcenter.com` 連線並執行惡意指令


檔案整理於下表

| 檔案名稱               | 檔案描述                                           | SHA256                                                             |
|------------------------|--------------------------------------------------|--------------------------------------------------------------------|
| [NSIS].nsi             | NSIS 安裝腳本                                     | 8ea8b83645fba6e23d48075a0d3fc73ad2ba515b4536710cda4f1f232718f53e     |
| BluetoothService.exe   | Bitdefender 程式（正常程式，用於 DLL side-loading） | 2da00de67720f5f13b17e9d985fe70f10f153da60c9ab1086fe58f069a156924     |
| BluetoothService       | 加密的負載                                         | 77bfea78def679aa1117f569a35e8fd1542df21f7e00e27f192c907e61d63a2e     |
| log.dll                | 惡意的 DLL 載入器                                  | 3bdc4c0637591533f1d4198a72a33426c01f69bd2e15ceee547866f65e26b7ad     |

# 防禦與緩解建議


# 偵測規則


## Snort Rule

```
alert tcp $EXTERNAL_NET any -> $HTTP_SERVERS 80 (msg:"ATTACK-RESPONSES /etc/passwd leakage attempt"; content:"/etc/passwd"; nocase; sid:1000001; rev:1; classtype:web-application-attack;)
```


# 附錄

## MITRE ATT&CK 
| ATT&CK ID   | Name                                                                 |
|------------|----------------------------------------------------------------------|
| T1204.002  | User Execution: Malicious File                                      |
| T1036      | Masquerading                                                         |
| T1027      | Obfuscated Files or Information                                      |
| T1027.007  | Obfuscated Files or Information: Dynamic API Resolution              |
| T1140      | Deobfuscate/Decode Files or Information                              |
| T1574.002  | DLL Side-Loading                                                     |
| T1106      | Native API                                                           |
| T1055      | Process Injection                                                    |
| T1620      | Reflective Code Loading                                              |
| T1059.003  | Command and Scripting Interpreter: Windows Command Shell            |
| T1083      | File and Directory Discovery                                         |
| T1005      | Data from Local System                                               |
| T1105      | Ingress Tool Transfer                                                |
| T1041      | Exfiltration Over C2 Channel                                         |
| T1071.001  | Application Layer Protocol: Web Protocols (HTTP/HTTPS)              |
| T1573      | Encrypted Channel                                                    |
| T1547.001  | Boot or Logon Autostart Execution: Registry Run Keys                |
| T1543.003  | Create or Modify System Process: Windows Service                    |
| T1480.002  | Execution Guardrails: Mutual Exclusion                               |
| T1070.004  | Indicator Removal on Host: File Deletion                             |
## IOC

| Filename              | SHA-256 |
|------------------------|------------------------|
|[NSIS].nsi|8ea8b83645fba6e23d48075a0d3fc73ad2ba515b4536710cda4f1f232718f53e|
|BluetoothService |77bfea78def679aa1117f569a35e8fd1542df21f7e00e27f192c907e61d63a2e|
|log.dll|3bdc4c0637591533f1d4198a72a33426c01f69bd2e15ceee547866f65e26b7ad|



| Indicator              |
|------------------------|
| 95.179.213.0           |
| api[.]skycloudcenter[.]com |
| api[.]wiresguard[.]com |
| 61.4.102.97            |
| 59.110.7.32            |
| 124.222.137.114        |

## Reference

- https://www.rapid7.com/blog/post/tr-chrysalis-backdoor-dive-into-lotus-blossoms-toolkit/